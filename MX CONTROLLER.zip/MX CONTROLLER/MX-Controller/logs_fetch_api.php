<?php
include 'includes/db.php';
$sql = "SELECT logs.id, controllers.name AS controller_name, logs.avg_speed, logs.traffic_density, logs.timestamp
        FROM logs 
        LEFT JOIN controllers ON logs.controller_id = controllers.id
        ORDER BY logs.timestamp DESC 
        LIMIT 20";
$result = $conn->query($sql);

$logs = [];
while($row = $result->fetch_assoc()) {
    $logs[] = $row;
}
header('Content-Type: application/json');
echo json_encode(['logs' => $logs]);
?>
