<?php
include '../includes/db.php';

$sql = "SELECT c.name as controller_name, AVG(l.avg_speed) as avg_speed, 
               l.traffic_density
        FROM logs l 
        JOIN controllers c ON l.controller_id = c.id 
        WHERE l.timestamp >= NOW() - INTERVAL 1 HOUR
        GROUP BY c.name, l.traffic_density";

$result = $conn->query($sql);
$data = [];
while($row = $result->fetch_assoc()){
    $data[] = [
        'controller_name' => $row['controller_name'],
        'avg_speed' => round($row['avg_speed'],1),
        'traffic_density' => $row['traffic_density']
    ];
}
header('Content-Type: application/json');
echo json_encode($data);
?>
