<?php
session_start();
if (!isset($_SESSION['loggedin'])) { echo json_encode(['error'=>'Not logged in']); exit; }
include 'includes/db.php';
// Sample chart data (average speed by day)
$data = $conn->query("SELECT DATE(timestamp) AS day, AVG(avg_speed) AS speed FROM logs GROUP BY day ORDER BY day");
$labels=[];$speeds=[];
while($row=$data->fetch_assoc()){ $labels[]=$row['day']; $speeds[]=$row['speed']; }
// Controllers distribution
$ctrl=$conn->query("SELECT status,COUNT(*) AS count FROM controllers GROUP BY status");
$controllerNames=[];$controllerCounts=[];
while($row=$ctrl->fetch_assoc()){ $controllerNames[]=$row['status']; $controllerCounts[]=$row['count']; }
echo json_encode(['labels'=>$labels,'speeds'=>$speeds,'controllerNames'=>$controllerNames,'controllerCounts'=>$controllerCounts]);
