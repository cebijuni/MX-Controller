<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 0;
}

$message = "";
require_once 'includes/db.php';

// Only admins can access this page
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Handle delete request
if (isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    if ($delete_id != $_SESSION['user_id']) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $delete_id);
        if ($stmt->execute()) {
            $message = "User deleted successfully.";
        } else {
            $message = "Error deleting user.";
        }
    } else {
        $message = "You cannot delete your own account while logged in.";
    }
}

// Fetch all users
$result = $conn->query("SELECT * FROM users ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('icons/background2.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        /* Purple theme */
        .navbar-purple {
            background-color: #e4afdeff!important; /* Purple navbar */
        }
        .container-purple {
            background-color: #e4afdeff; /* Purple container */
            color: white;
            border-radius: 10px;
            padding: 20px;
        }
        .table-purple {
            background-color: #e4afdeff !important; /* Lighter purple for table */
            color: white;
        }
        .table-purple thead {
            background-color: #e4afdeff !important; /* Darker purple for table header */
        }
        .table-purple tbody tr:nth-child(odd) {
            background-color: #e4afdeff !important; /* Alternate row color */
        }
        .table-purple tbody tr:nth-child(even) {
            background-color: #e4afdeff !important;
        }
        .stamp {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 120px;
            opacity: 0.8;
            z-index: 9999;
            pointer-events: none;
        }1
        @keyframes fadeStamp {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.9; }
        }
        .marquee-outer {
            height: 65px;    
            display: flex;
            align-items: center;
        }
        .marquee-inner img {
            animation: blink 1.5s ease-in-out infinite;
        }
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0; }
        }
    </style>
</head>
<body class="bg-dark text-light">

<!-- Purple Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-purple">
    <div class="container-fluid d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center">
            <div class="marquee-outer me-4">
                <div class="marquee-inner">
                    <img src="icons/logo.png" width="150" height="65" alt="Swimming fish">
                </div>
            </div>
            <div class="collapse navbar-collapse show" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link active" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="devices.php">Devices</a></li>
                    <li class="nav-item"><a class="nav-link" href="logs.php">Logs</a></li>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link text-warning" href="create_user.php">+ Create User</a></li>
                        <li class="nav-item"><a class="nav-link" href="users.php">View Users</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <a class="btn btn-outline-light" href="logout.php">Logout</a>
    </div>
</nav>

<!-- Purple Container -->
<div class="container mt-5 container-purple">
    <h3 class="mb-4">All Users</h3>
    <?php if($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <table class="table table-striped table-purple">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td><?= $row['role'] ?></td>
                <td>
                    <?php if($row['id'] != $_SESSION['user_id']): ?>
                        <a href="users.php?delete=<?= $row['id'] ?>" class="btn btn-danger btn-sm" 
                           onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                    <?php else: ?>
                        <span class="text-muted">Current User</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    <a href="dashboard.php" class="btn btn-outline-light">Back to Dashboard</a>
</div>

<!-- Bottom-right stamp -->
<img src="icons/logo2.png" alt="Stamp" class="stamp">
<script>
function showAlert(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-bg-${type} border-0 mb-2 show`;
    toast.role = "alert";
    toast.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div>
                       <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
}

function randomizeDevices() {
    fetch('api/device_randomizer.php')
        .then(res => res.json())
        .then(data => {
            if (data.changes.length > 0) {
                data.changes.forEach(change => {
                    showAlert(`Device <b>${change.name}</b> changed from <b>${change.old_status}</b> to <b>${change.new_status}</b>`,
                              change.new_status === 'Offline' ? 'danger' : 'success');
                });
                location.reload();
            }
        });
}
setInterval(randomizeDevices, 15000); // every 15s
</script>

<!-- Toast container -->
<div id="toast-container" class="toast-container position-fixed top-0 end-0 p-3"></div>

</body>
</html>
