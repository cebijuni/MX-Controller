-- Drop old tables if they exist
DROP TABLE IF EXISTS logs;
DROP TABLE IF EXISTS controllers;
DROP TABLE IF EXISTS users;

-- Create Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','user') DEFAULT 'user'
);

-- Default admin user (password: admin123)
INSERT INTO users (username, password, role)
VALUES ('admin', '$2y$10$9yWvNcQpB1ZaEjmqjBSX1eJPQ3Cdl27lLG8E1jcq1KTxoDNlT69lO', 'admin');

-- Create Controllers table
CREATE TABLE controllers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    status ENUM('Online','Offline','Maintenance') DEFAULT 'Online'
);

-- Sample Controllers
INSERT INTO controllers (name, status) VALUES
('MXC-101', 'Online'),
('MXC-102', 'Online'),
('MXC-103', 'Offline'),
('MXC-104', 'Online'),
('MXC-105', 'Maintenance');

-- Create Logs table
CREATE TABLE logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    controller_id INT NOT NULL,
    avg_speed DECIMAL(5,2),
    traffic_density VARCHAR(50),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (controller_id) REFERENCES controllers(id)
);

-- Sample Logs (3 days)
INSERT INTO logs (controller_id, avg_speed, traffic_density, timestamp) VALUES
(1, 45, 'Medium', '2025-07-20 08:00:00'),
(1, 50, 'Medium', '2025-07-20 12:00:00'),
(2, 38, 'High',   '2025-07-20 09:00:00'),
(2, 40, 'High',   '2025-07-20 13:00:00'),
(3, 0,  'Offline','2025-07-20 14:00:00'),
(4, 55, 'Low',    '2025-07-20 10:00:00'),
(4, 60, 'Medium', '2025-07-21 11:00:00'),
(5, 30, 'Maintenance', '2025-07-21 15:00:00'),
(1, 52, 'Medium', '2025-07-21 16:00:00'),
(2, 47, 'High',   '2025-07-21 17:00:00'),
(3, 0,  'Offline','2025-07-22 09:00:00'),
(4, 62, 'Low',    '2025-07-22 12:00:00'),
(5, 29, 'Maintenance','2025-07-22 13:00:00');
