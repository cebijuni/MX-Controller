<?php
// config.php - Database connection configuration

$host = "localhost";        // Usually localhost on XAMPP
$username = "root";         // Default XAMPP MySQL username
$password = "";             // Default XAMPP MySQL password is empty
$db_name = "mx_controller_db";  // Your database name

// Create connection
$conn = mysqli_connect($host, $username, $password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
