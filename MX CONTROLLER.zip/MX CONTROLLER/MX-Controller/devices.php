<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$alert = "";

// Add Device
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_device'])) {
    $stmt = $conn->prepare("INSERT INTO controllers (name, controller_type, location, status, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssdd", $_POST['name'], $_POST['controller_type'], $_POST['location'], $_POST['status'], $_POST['latitude'], $_POST['longitude']);
    $stmt->execute();
    $alert = "Device added successfully.";
}

// Edit Device
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_device'])) {
    $stmt = $conn->prepare("UPDATE controllers SET name=?, controller_type=?, location=?, status=?, latitude=?, longitude=? WHERE id=?");
    $stmt->bind_param("ssssddi", $_POST['name'], $_POST['controller_type'], $_POST['location'], $_POST['status'], $_POST['latitude'], $_POST['longitude'], $_POST['device_id']);
    $stmt->execute();
    $alert = "Device updated successfully.";
}

// Delete Device
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_device'])) {
    $stmt = $conn->prepare("DELETE FROM controllers WHERE id=?");
    $stmt->bind_param("i", $_POST['device_id']);
    $stmt->execute();
    $alert = "Device deleted successfully.";
}

// Fetch devices
$result = $conn->query("SELECT * FROM controllers");
$controllers = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devices</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />

    <style>
        body {
            background: url('icons/background2.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #fff;
        }

        .custom-purple {
            background-color: #e4afdeff !important;
            color: #fff !important;
        }

        .card {
            background-color: #e4afdeff !important;
            color: #fff;
        }

        .modal-content {
            background-color: #e4afdeff !important;
            color: #fff;
        }

        .form-control,
        .form-select {
            background-color: #644e62ff;
            color: #fff;
            border: 1px solid #555;
        }

        .stamp {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 120px;
            opacity: 0.8;
            z-index: 9999;
            pointer-events: none;
        }

        .marquee-outer {
            height: 65px;
            display: flex;
            align-items: center;
        }

        .marquee-inner img {
            animation: blink 1.5s ease-in-out infinite;
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0; }
        }

        #deviceMap {
            height: 400px;
            width: 100%;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark custom-purple">
    <div class="container-fluid d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center">
            <div class="marquee-outer me-4">
                <div class="marquee-inner">
                    <img src="icons/logo.png" width="150" height="65" alt="Swimming fish">
                </div>
            </div>
            <div class="collapse navbar-collapse show" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link active" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="devices.php">Devices</a></li>
                    <li class="nav-item"><a class="nav-link" href="logs.php">Logs</a></li>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link text-warning" href="create_user.php">+ Create User</a></li>
                        <li class="nav-item"><a class="nav-link" href="users.php">View Users</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <a class="btn btn-outline-light" href="logout.php">Logout</a>
    </div>
</nav>

<div class="container mt-4">
    <h2>Device List</h2>
    <?php if ($alert): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $alert ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card p-3">
        <table class="table table-dark table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Controller Type</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($controllers as $device): ?>
                <tr>
                    <td><?= htmlspecialchars($device['name']) ?></td>
                    <td><?= htmlspecialchars($device['controller_type']) ?></td>
                    <td><?= htmlspecialchars($device['location']) ?></td>
                    <td><?= htmlspecialchars($device['status']) ?></td>
                    <td><?= htmlspecialchars($device['latitude']) ?></td>
                    <td><?= htmlspecialchars($device['longitude']) ?></td>
                    <td>
                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editDeviceModal<?= $device['id'] ?>">Edit</button>
                        <form method="POST" action="" style="display:inline-block;" onsubmit="return confirm('Are you sure?');">
                            <input type="hidden" name="device_id" value="<?= $device['id'] ?>">
                            <button type="submit" name="delete_device" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>

                <!-- Edit Modal -->
                <div class="modal fade" id="editDeviceModal<?= $device['id'] ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Device</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="device_id" value="<?= $device['id'] ?>">
                                    <div class="mb-3">
                                        <label>Name</label>
                                        <input type="text" name="name" class="form-control" value="<?= $device['name'] ?>" required>
                                    </div>
                                    <div class="mb-3">
  <label>Type of Controller</label>
  <select name="controller_type" class="form-select">
    <option <?= $device['controller_type']=='MX Maxi Controller'?'selected':'' ?>>MX Maxi Controller</option>
    <option <?= $device['controller_type']=='MX STD Controller'?'selected':'' ?>>MX STD Controller</option>
    <option <?= $device['controller_type']=='MX Lite Controller'?'selected':'' ?>>MX Lite Controller</option>
    <option <?= $device['controller_type']=='MX M20 Controller'?'selected':'' ?>>MX M20 Controller</option>
    <option <?= $device['controller_type']=='MX Pedestrian Controller'?'selected':'' ?>>MX Pedestrian Controller</option>
  </select>
</div>


                                    <div class="mb-3">
                                        <label>Location</label>
                                        <input type="text" name="location" class="form-control" value="<?= $device['location'] ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Status</label>
                                        <select name="status" class="form-select">
                                            <option <?= $device['status']=='Online'?'selected':'' ?>>Online</option>
                                            <option <?= $device['status']=='Offline'?'selected':'' ?>>Offline</option>
                                            <option <?= $device['status']=='Maintenance'?'selected':'' ?>>Maintenance</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Latitude</label>
                                        <input type="number" step="any" name="latitude" class="form-control" value="<?= $device['latitude'] ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Longitude</label>
                                        <input type="number" step="any" name="longitude" class="form-control" value="<?= $device['longitude'] ?>">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" name="edit_device" class="btn btn-primary">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </tbody>
        </table>
            <button class="btn btn-success mb-3" style="background-color:#cb77e0ff" data-bs-toggle="modal" data-bs-target="#addDeviceModal">Add Device</button>
    </div>

    <!-- Add Device Modal -->
    <div class="modal fade" id="addDeviceModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Device</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3"><label>Name</label><input type="text" name="name" class="form-control" required></div>
                        <div class="mb-3">
                                    <label>Type of Controller</label>
                                    <select name="controller_type" class="form-select">
                                     <option>MX Maxi Controller</option>
                                        <option>MX STD Controller</option>
                                     <option>MX Lite Controller</option>
                                    <option>MX M20 Controller</option>
                                    <option>MX Pedestrian Controller</option>
                                     </select>
                                    </div>
                        <div class="mb-3"><label>Location</label><input type="text" name="location" class="form-control" required></div>
                        <div class="mb-3">
                            <label>Status</label>
                            <select name="status" class="form-select">
                                <option>Online</option><option>Offline</option><option>Maintenance</option>
                            </select>
                        </div>
                        <div class="mb-3"><label>Latitude</label><input type="number" step="any" name="latitude" class="form-control"></div>
                        <div class="mb-3"><label>Longitude</label><input type="number" step="any" name="longitude" class="form-control"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="add_device" class="btn btn-success">Add Device</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Map Card -->
    <div class="card p-3 mt-4">
        <h4>Device Locations</h4>
        <div id="deviceMap"></div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script>
const controllers = <?= json_encode($controllers); ?>;
const map = L.map('deviceMap').setView([-28.4793, 24.6727], 6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors' }).addTo(map);

const icons = {
    Online: new L.Icon({iconUrl: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png', iconSize:[32,32]}),
    Offline: new L.Icon({iconUrl: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png', iconSize:[32,32]}),
    Maintenance: new L.Icon({iconUrl: 'https://maps.google.com/mapfiles/ms/icons/orange-dot.png', iconSize:[32,32]})
};

controllers.forEach(d => {
    if (d.latitude && d.longitude) {
        const marker = L.marker([parseFloat(d.latitude), parseFloat(d.longitude)], {icon: icons[d.status]}).addTo(map);
        marker.bindPopup(`<b>${d.name}</b><br>${d.location}<br>Status: ${d.status}`);
    }
});
</script>

<img src="icons/logo2.png" alt="Stamp" class="stamp">
<script>
function showAlert(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-bg-${type} border-0 mb-2 show`;
    toast.role = "alert";
    toast.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div>
                       <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
}

function randomizeDevices() {
    fetch('api/device_randomizer.php')
        .then(res => res.json())
        .then(data => {
            if (data.changes.length > 0) {
                data.changes.forEach(change => {
                    showAlert(`Device <b>${change.name}</b> changed from <b>${change.old_status}</b> to <b>${change.new_status}</b>`,
                              change.new_status === 'Offline' ? 'danger' : 'success');
                });
                location.reload();
            }
        });
}
setInterval(randomizeDevices, 15000); // every 15s
</script>

<!-- Toast container -->
<div id="toast-container" class="toast-container position-fixed top-0 end-0 p-3"></div>

</body>
</html>
