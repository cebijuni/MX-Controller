<a href="report_logs.php" class="btn btn-danger mb-3">Download PDF Report</a>
