<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

require 'includes/dompdf/autoload.inc.php';
use Dompdf\Dompdf;

include 'includes/db.php';

// Fetch log data
$result = $conn->query("SELECT logs.id, controllers.name AS controller_name, logs.avg_speed, logs.traffic_density, logs.timestamp 
                        FROM logs 
                        LEFT JOIN controllers ON logs.controller_id = controllers.id
                        ORDER BY logs.timestamp DESC");

// Build HTML for PDF
$html = '<h2>Traffic Logs Report</h2>';
$html .= '<table border="1" cellspacing="0" cellpadding="5" width="100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Controller</th>
                    <th>Avg Speed</th>
                    <th>Traffic Density</th>
                    <th>Timestamp</th>
                </tr>
            </thead><tbody>';
while ($row = $result->fetch_assoc()) {
    $html .= '<tr>
                <td>'.$row['id'].'</td>
                <td>'.$row['controller_name'].'</td>
                <td>'.$row['avg_speed'].'</td>
                <td>'.$row['traffic_density'].'</td>
                <td>'.$row['timestamp'].'</td>
              </tr>';
}
$html .= '</tbody></table>';

// Create PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$dompdf->stream("traffic_logs.pdf", ["Attachment" => 1]);
