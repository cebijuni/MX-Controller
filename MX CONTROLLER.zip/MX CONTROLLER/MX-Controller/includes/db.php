<?php
$host = 'localhost';
$user = 'root';   // default for XAMPP
$pass = '';       // leave empty for XAMPP
$db   = 'mx_controller';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die('Database Connection Failed: ' . $conn->connect_error);
}
?>
