<?php
session_start();
$_SESSION['loggedin'] = true;
$_SESSION['username'] = 'admin';
$_SESSION['role'] = 'admin';
$_SESSION['last_activity'] = time();
header('Location: dashboard.php');
exit;
?>
