<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}
require 'includes/dompdf/autoload.inc.php';
use Dompdf\Dompdf;
include 'includes/db.php';

// Uptime (percentage online)
$controllers = $conn->query("SELECT 
    SUM(status='Online') AS online, COUNT(*) AS total FROM controllers");
$cData = $controllers->fetch_assoc();
$uptime = ($cData['total'] > 0) ? round(($cData['online']/$cData['total']) * 100, 2) : 0;

// Average speed
$speedAvg = $conn->query("SELECT AVG(avg_speed) AS speed_avg FROM logs")->fetch_assoc()['speed_avg'];

// Build HTML
$html = "
<h2>System Analytics Summary</h2>
<p><b>Controller Uptime:</b> {$uptime}%</p>
<p><b>Average Speed (All Logs):</b> {$speedAvg} km/h</p>
<p>Generated on: ".date('Y-m-d H:i:s')."</p>
";

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("analytics_summary.pdf", ["Attachment" => 1]);
