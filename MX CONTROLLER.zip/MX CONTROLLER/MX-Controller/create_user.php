<?php
session_start();
require_once 'includes/db.php';

// Only allow if logged in as admin
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = password_hash(trim($_POST['password']), PASSWORD_BCRYPT);
    $role = $_POST['role'];

    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $password, $role);

    if ($stmt->execute()) {
        $message = "User '$username' created successfully!";
    } else {
        $message = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create User</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('icons/background2.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }

        .stamp {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 120px;
            opacity: 0.8;
            z-index: 9999;
            pointer-events: none;
        }

        .marquee-outer {
            height: 65px;	
            display: flex;
            align-items: center;
        }

        .marquee-inner img {
            animation: blink 1.5s ease-in-out infinite;
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0; }
        }

        .custom-bg {
            background-color: #e4afdeff !important;
        }
         h4 {
        color: white;
    }
    </style>
</head>
<body class="text-dark">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg custom-bg navbar-dark">
    <div class="container-fluid d-flex align-items-center justify-content-between">
        <!-- Left side: Logo + Menu -->
        <div class="d-flex align-items-center">
            <!-- Logo -->
            <div class="marquee-outer me-4">
                <div class="marquee-inner">
                    <img src="icons/logo.png" width="150" height="65" alt="Swimming fish">
                </div>
            </div>

            <!-- Navigation links -->
            <div class="collapse navbar-collapse show" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link active" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="devices.php">Devices</a></li>
                    <li class="nav-item"><a class="nav-link" href="logs.php">Logs</a></li>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link text-warning" href="create_user.php">+ Create User</a></li>
                        <li class="nav-item"><a class="nav-link" href="users.php">View Users</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <!-- Right side: Logout -->
        <a class="btn btn-outline-light" href="logout.php">Logout</a>
    </div>
</nav>

<!-- User creation form -->
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card custom-bg text-dark">
                <div class="card-header custom-bg text-dark">
                    <h4>Create New User</h4>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-info"><?= $message ?></div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select name="role" class="form-select" required>
                                <option value="admin">Admin</option>
                                <option value="user">User</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-dark w-100">Create User</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bottom-right stamp -->
<img src="icons/logo2.png" alt="Stamp" class="stamp">

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
