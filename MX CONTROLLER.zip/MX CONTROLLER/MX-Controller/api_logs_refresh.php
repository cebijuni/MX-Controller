<?php
session_start();
if (!isset($_SESSION['loggedin'])) { echo json_encode(['error'=>'Not logged in']); exit; }
include 'includes/db.php';
$offline=$conn->query("SELECT name FROM controllers WHERE status='Offline' LIMIT 1");
$alert='';
if($offline && $offline->num_rows>0){ $row=$offline->fetch_assoc(); $alert="Controller '{$row['name']}' is offline!"; }
$log=$conn->query("SELECT logs.id,controllers.name AS controller,logs.avg_speed FROM logs LEFT JOIN controllers ON logs.controller_id=controllers.id ORDER BY logs.id DESC LIMIT 1");
$newLog=$log->fetch_assoc();
echo json_encode(['alert'=>$alert,'newLog'=>$newLog]);
