<?php
require_once 'includes/db.php';

// Username and password for the admin account
$username = 'admin';
$password = 'admin123';
$hash = password_hash($password, PASSWORD_BCRYPT);
$role = 'admin';

// Check if admin already exists
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "Admin user already exists. <a href='login.php'>Go to login</a>";
} else {
    $insert = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    $insert->bind_param("sss", $username, $hash, $role);
    if ($insert->execute()) {
        echo "Admin user created successfully.<br>";
        echo "Username: admin<br>Password: admin123<br>";
        echo "<a href='login.php'>Go to login</a>";
    } else {
        echo "Error creating admin: " . $conn->error;
    }
}
?>
