<?php
session_start();
if (!isset($_SESSION['loggedin'])) { header('Location: login.php'); exit; }
include 'includes/db.php';
header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=logs_export.csv');
$output = fopen('php://output', 'w');
fputcsv($output, ['ID','Controller','Average Speed','Traffic Density','Timestamp']);
$sql="SELECT logs.id,controllers.name AS controller_name,logs.avg_speed,logs.traffic_density,logs.timestamp FROM logs LEFT JOIN controllers ON logs.controller_id=controllers.id ORDER BY logs.timestamp DESC";
$res=$conn->query($sql);
while($row=$res->fetch_assoc()){ fputcsv($output,[$row['id'],$row['controller_name'],$row['avg_speed'],$row['traffic_density'],$row['timestamp']]); }
fclose($output);
exit;
