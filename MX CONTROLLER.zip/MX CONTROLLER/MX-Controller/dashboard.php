<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['loggedin'])) {
    header("Location: login.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Initial counts (fallback if JS fails)
$controller_count = $conn->query("SELECT COUNT(*) AS total FROM controllers")->fetch_assoc()['total'];
$log_count = $conn->query("SELECT COUNT(*) AS total FROM logs")->fetch_assoc()['total'];
$user_count = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MX Controller - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: url('icons/background2.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        .custom-purple { background-color: #e4afdeff !important; }
        .stamp {
            position: fixed; bottom: 20px; right: 20px;
            width: 120px; opacity: 0.8; z-index: 9999; pointer-events: none;
        }
        .marquee-outer { height: 65px; display: flex; align-items: center; }
        .marquee-inner img { animation: blink 1.5s ease-in-out infinite; }
        @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
        .small-card { height: 350px; }
        .small-card canvas { height: 250px !important; }
        .wide-card { height: 400px; }
        .wide-card .card-body { height: calc(100% - 56px); display: flex; align-items: center; }
        #combinedLineChart { width: 100% !important; height: 100% !important; }
        #densityLegend li { font-size: 14px; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark custom-purple">
    <div class="container-fluid d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center">
            <div class="marquee-outer me-4">
                <div class="marquee-inner">
                    <img src="icons/logo.png" width="150" height="65" alt="Logo">
                </div>
            </div>
            <div class="collapse navbar-collapse show" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link active" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="devices.php">Devices</a></li>
                    <li class="nav-item"><a class="nav-link" href="logs.php">Logs</a></li>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link text-warning" href="create_user.php">+ Create User</a></li>
                        <li class="nav-item"><a class="nav-link" href="users.php">View Users</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <a class="btn btn-outline-light" href="logout.php">Logout</a>
    </div>
</nav>

<div class="container mt-4">
    <h2>Welcome, <?= htmlspecialchars($_SESSION['username']) ?>!</h2>

    <!-- Cards row -->
    <div class="row text-center mt-4">
        <div class="col-md-4">
            <a href="devices.php" class="text-decoration-none">
                <div class="card custom-purple text-light mb-3">
                    <div class="card-body">
                        <h5 class="card-title text-light">Controllers</h5>
                        <h3 class="text-light" id="controller-count"><?= $controller_count ?></h3>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="logs.php" class="text-decoration-none">
                <div class="card custom-purple text-light mb-3">
                    <div class="card-body">
                        <h5 class="card-title text-light">Logs</h5>
                        <h3 class="text-light" id="log-count"><?= $log_count ?></h3>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="users.php" class="text-decoration-none">
                <div class="card custom-purple text-light mb-3">
                    <div class="card-body">
                        <h5 class="card-title text-light">Users</h5>
                        <h3 class="text-light" id="user-count"><?= $user_count ?></h3>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row mt-5">
        <div class="col-md-6">
            <div class="card custom-purple text-light mb-3 small-card">
                <div class="card-header">Average Speed per Controller</div>
                <div class="card-body">
                    <canvas id="speedChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card custom-purple text-light mb-3 small-card">
                <div class="card-header">Traffic Density</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-7"><canvas id="densityChart"></canvas></div>
                        <div class="col-5 d-flex align-items-center">
                            <ul id="densityLegend" class="list-unstyled mb-0 w-100"></ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Full Width Line Chart -->
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="card custom-purple text-light mb-3 wide-card">
                <div class="card-header">Speed & Density Trend</div>
                <div class="card-body p-0">
                    <canvas id="combinedLineChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-3">
  <div class="col-md-12">
    <div class="card custom-purple text-light mb-3 wide-card">
      <div class="card-header">System Performance</div>
      <div class="card-body p-0">
        <canvas id="performanceChart"></canvas>
      </div>
    </div>
  </div>
</div>
</div>

<img src="icons/logo2.png" alt="Stamp" class="stamp">

<script>
let speedChart, densityChart, combinedLineChart;

function fetchStats() {
    fetch('api/dashboard_stats.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('controller-count').innerText = data.controllers;
            document.getElementById('log-count').innerText = data.logs;
            document.getElementById('user-count').innerText = data.users;
        });
}

function fetchAndUpdateCharts() {
    fetch('api/get_logs.php')
        .then(response => response.json())
        .then(data => {
            const labels = data.map(row => row.controller_name);
            const speeds = data.map(row => row.avg_speed);

            // Traffic Density Count
            const densityMap = {};
            data.forEach(row => {
                const density = row.traffic_density || "Unknown";
                densityMap[density] = (densityMap[density] || 0) + 1;
            });

            // Speed Bar Chart
            if (!speedChart) {
                speedChart = new Chart(document.getElementById('speedChart').getContext('2d'), {
                    type: 'bar',
                    data: { labels, datasets: [{ label: 'Average Speed (km/h)', data: speeds, backgroundColor: 'rgba(54, 162, 235, 0.7)' }] },
                    options: { responsive: true }
                });
            } else {
                speedChart.data.labels = labels;
                speedChart.data.datasets[0].data = speeds;
                speedChart.update();
            }

            // Density Pie Chart
            const densityLabels = Object.keys(densityMap);
            const densityValues = Object.values(densityMap);
            const densityColors = ['#0d6efd', '#ffc107', '#dc3545', '#198754', '#6f42c1', '#fd7e14'];
            if (!densityChart) {
                densityChart = new Chart(document.getElementById('densityChart').getContext('2d'), {
                    type: 'pie',
                    data: { labels: densityLabels, datasets: [{ data: densityValues, backgroundColor: densityColors }] },
                    options: { responsive: true, plugins: { legend: { display: false } } }
                });
            } else {
                densityChart.data.labels = densityLabels;
                densityChart.data.datasets[0].data = densityValues;
                densityChart.update();
            }

            // Custom Legend
            const legendContainer = document.getElementById('densityLegend');
            legendContainer.innerHTML = '';
            densityLabels.forEach((label, index) => {
                const color = densityColors[index % densityColors.length];
                legendContainer.innerHTML += `<li class="d-flex align-items-center mb-1">
                    <span style="display:inline-block;width:15px;height:15px;background:${color};margin-right:8px;border-radius:3px;"></span>
                    ${label}: ${densityValues[index]}
                </li>`;
            });

            // Combined Line Chart
            const densitiesCount = densityValues;
            if (!combinedLineChart) {
                combinedLineChart = new Chart(document.getElementById('combinedLineChart').getContext('2d'), {
                    type: 'line',
                    data: {
                        labels,
                        datasets: [
                            { label: 'Average Speed (km/h)', data: speeds, borderColor: 'rgba(54, 162, 235, 1)', backgroundColor: 'rgba(54, 162, 235, 0.2)', yAxisID: 'y' },
                            { label: 'Density Count', data: densitiesCount, borderColor: 'rgba(255, 99, 132, 1)', backgroundColor: 'rgba(255, 99, 132, 0.2)', yAxisID: 'y1' }
                        ]
                    },
                    options: {
                        responsive: true,
                        interaction: { mode: 'index', intersect: false },
                        stacked: false,
                        scales: {
                            y: { type: 'linear', position: 'left' },
                            y1: { type: 'linear', position: 'right', grid: { drawOnChartArea: false } }
                        }
                    }
                });
            } else {
                combinedLineChart.data.labels = labels;
                combinedLineChart.data.datasets[0].data = speeds;
                combinedLineChart.data.datasets[1].data = densitiesCount;
                combinedLineChart.update();
            }
        });
let performanceChart;
let performanceLabels = [];
let onlineData = [], offlineData = [], maintenanceData = [];

function fetchPerformanceData() {
  fetch('api/performance_data.php')
    .then(res => res.json())
    .then(data => {
      const now = new Date().toLocaleTimeString();
      performanceLabels.push(now);
      if (performanceLabels.length > 10) performanceLabels.shift();

      onlineData.push(data.Online); if (onlineData.length > 10) onlineData.shift();
      offlineData.push(data.Offline); if (offlineData.length > 10) offlineData.shift();
      maintenanceData.push(data.Maintenance); if (maintenanceData.length > 10) maintenanceData.shift();

      if (!performanceChart) {
        const ctx = document.getElementById('performanceChart').getContext('2d');
        performanceChart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: performanceLabels,
            datasets: [
              {
                label: 'Online',
                data: onlineData,
                borderColor: 'rgba(0, 128, 0, 1)',
                backgroundColor: 'rgba(0, 128, 0, 0.3)',
                fill: true
              },
              {
                label: 'Offline',
                data: offlineData,
                borderColor: 'rgba(255, 0, 0, 1)',
                backgroundColor: 'rgba(255, 0, 0, 0.3)',
                fill: true
              },
              {
                label: 'Maintenance',
                data: maintenanceData,
                borderColor: 'rgba(255, 165, 0, 1)',
                backgroundColor: 'rgba(255, 165, 0, 0.3)',
                fill: true
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: { legend: { display: true } },
            scales: {
              y: { beginAtZero: true },
              x: { display: true }
            }
          }
        });
      } else {
        performanceChart.update();
      }
    });
}
fetchPerformanceData();
setInterval(fetchPerformanceData, 10000);
}

// Initial fetch
fetchStats();
fetchAndUpdateCharts();
setInterval(() => { fetchStats(); fetchAndUpdateCharts(); }, 10000);
</script>
<script>
function showAlert(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-bg-${type} border-0 mb-2 show`;
    toast.role = "alert";
    toast.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div>
                       <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
}


function randomizeDevices() {
    fetch('api/device_randomizer.php')
        .then(res => res.json())
        .then(data => {
            if (data.changes.length > 0) {
                data.changes.forEach(change => {
                    showAlert(`Device <b>${change.name}</b> changed from <b>${change.old_status}</b> to <b>${change.new_status}</b>`,
                              change.new_status === 'Offline' ? 'danger' : 'success');
                });
                location.reload();
            }
        });
}
setInterval(randomizeDevices, 15000); // every 15s
</script>

<!-- Toast container -->
<div id="toast-container" class="toast-container position-fixed top-0 end-0 p-3"></div>

</body>
</html>
