let lastLogId=0;
function checkNotifications(){
 fetch('api_notifications.php')
  .then(res=>res.json())
  .then(data=>{
    if(data.alert){ showToast('Controller Offline',data.alert); }
    if(data.newLog && data.newLog.id>lastLogId){
        lastLogId=data.newLog.id;
        showToast('New Traffic Log',`Controller: ${data.newLog.controller}, Speed: ${data.newLog.avg_speed} km/h`);
    }
  });
}
function showToast(title,message){
 const toastHTML=`<div class="toast align-items-center text-bg-primary border-0" role="alert"><div class="d-flex"><div class="toast-body"><strong>${title}:</strong> ${message}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div>`;
 const container=document.getElementById('toast-container'); container.insertAdjacentHTML('beforeend',toastHTML);
 const toastEl=container.lastElementChild; new bootstrap.Toast(toastEl,{delay:5000}).show();
}
setInterval(checkNotifications,5000);
