<?php
session_start();
if (!isset($_SESSION['loggedin'])) { header('Location: login.php'); exit; }
if (time() - $_SESSION['last_activity'] > 1800) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['last_activity'] = time();

include 'includes/db.php';

// ---- Simulate random log insertion for demo ----
$controllers = mysqli_query($conn, "SELECT id FROM controllers");
$controller_ids = [];
while($c = mysqli_fetch_assoc($controllers)) { $controller_ids[] = $c['id']; }
if (!empty($controller_ids)) {
    $randomController = $controller_ids[array_rand($controller_ids)];
    $randomSpeed = rand(20,120);
    $randomDensity = rand(10,100) . "%";
    // Insert log slightly in the past (-0 to -5 minutes)
    mysqli_query($conn, "INSERT INTO logs (controller_id, avg_speed, traffic_density, timestamp) 
                         VALUES ($randomController, $randomSpeed, '$randomDensity', 
                         NOW() - INTERVAL FLOOR(RAND()*5) MINUTE)");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Logs</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: url('icons/background2.jpg') no-repeat center center fixed;
    background-size: cover;
    margin: 0; padding: 0;
}
.custom-purple { background-color: #e4afdeff !important; color: #644e62ff !important; }
.card.custom-purple { background-color: #e4afdeff !important; color: #644e62ff !important; }
.navbar.custom-purple { background-color: #e4afdeff !important; }
.stamp { position: fixed; bottom: 20px; right: 20px; width: 120px; opacity: 0.8; z-index: 9999; pointer-events: none; }
.marquee-outer { height: 65px; display: flex; align-items: center; }
.marquee-inner img { animation: blink 1.5s ease-in-out infinite; }
@keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
.custom-logout { background-color: transparent; border: 1px #644e62ff; color: #644e62ff !important; }
h1 { color: white; }
.table thead th, .table tbody td { color: #ffffffff; }
</style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark custom-purple">
    <div class="container-fluid d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center">
            <div class="marquee-outer me-4">
                <div class="marquee-inner">
                    <img src="icons/logo.png" width="150" height="65" alt="logo">
                </div>
            </div>
            <div class="collapse navbar-collapse show" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link active" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="devices.php">Devices</a></li>
                    <li class="nav-item"><a class="nav-link" href="logs.php">Logs</a></li>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link text-warning" href="create_user.php">+ Create User</a></li>
                        <li class="nav-item"><a class="nav-link" href="users.php">View Users</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <a class="btn custom-logout" href="logout.php">Logout</a>
    </div>
</nav>

<div class="container mt-4">
    <h1>Logs</h1>
    <div class="card custom-purple p-3">
        <table class="table table-dark table-striped" id="logs-table">
            <thead>
                <tr><th>ID</th><th>Controller</th><th>Avg Speed</th><th>Traffic Density</th><th>Timestamp</th></tr>
            </thead>
            <tbody>
                <!-- Logs will be loaded by AJAX -->
            </tbody>
        </table>
        <a href="export_logs.php" class="btn mb-3" style="background-color:#cb77e0ff;color:white;border:none;">
            Export Logs to CSV
        </a>
    </div>
</div>

<img src="icons/logo2.png" alt="Stamp" class="stamp">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Fetch logs dynamically without page reload
function fetchLogs(){
 fetch('logs_fetch_api.php')
    .then(res => res.json())
    .then(data => {
        const tbody = document.querySelector('#logs-table tbody');
        tbody.innerHTML = '';
        data.logs.forEach(log => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${log.id}</td>
                <td>${log.controller_name}</td>
                <td>${log.avg_speed}</td>
                <td>${log.traffic_density}</td>
                <td>${log.timestamp}</td>
            `;
            tbody.appendChild(tr);
        });
    });
}
// Fetch logs every 5 seconds
setInterval(fetchLogs, 5000);
fetchLogs();
</script>
<script>
function showAlert(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-bg-${type} border-0 mb-2 show`;
    toast.role = "alert";
    toast.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div>
                       <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
}

function randomizeDevices() {
    fetch('api/device_randomizer.php')
        .then(res => res.json())
        .then(data => {
            if (data.changes.length > 0) {
                data.changes.forEach(change => {
                    showAlert(`Device <b>${change.name}</b> changed from <b>${change.old_status}</b> to <b>${change.new_status}</b>`,
                              change.new_status === 'Offline' ? 'danger' : 'success');
                });
                location.reload();
            }
        });
}
setInterval(randomizeDevices, 15000); // every 15s
</script>

<!-- Toast container -->
<div id="toast-container" class="toast-container position-fixed top-0 end-0 p-3"></div>

</body>
</html>
