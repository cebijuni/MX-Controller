-- Create sample controllers
INSERT INTO controllers (name, status) VALUES
('MXC-101', 'Online'),
('MXC-102', 'Online'),
('MXC-103', 'Offline'),
('MXC-104', 'Online'),
('MXC-105', 'Maintenance');

-- Create sample logs
INSERT INTO logs (controller_id, avg_speed, traffic_density, timestamp) VALUES
(1, 45, 'Medium', '2025-07-20 08:00:00'),
(1, 50, 'Medium', '2025-07-20 12:00:00'),
(2, 38, 'High',   '2025-07-20 09:00:00'),
(2, 40, 'High',   '2025-07-20 13:00:00'),
(3, 0,  'Offline','2025-07-20 14:00:00'),
(4, 55, 'Low',    '2025-07-20 10:00:00'),
(4, 60, 'Medium', '2025-07-21 11:00:00'),
(5, 30, 'Maintenance', '2025-07-21 15:00:00'),
(1, 52, 'Medium', '2025-07-21 16:00:00'),
(2, 47, 'High',   '2025-07-21 17:00:00'),
(3, 0,  'Offline','2025-07-22 09:00:00'),
(4, 62, 'Low',    '2025-07-22 12:00:00'),
(5, 29, 'Maintenance','2025-07-22 13:00:00');
