<?php
include '../includes/db.php';

$response = [
    'controllers' => $conn->query("SELECT COUNT(*) as total FROM controllers")->fetch_assoc()['total'],
    'logs' => $conn->query("SELECT COUNT(*) as total FROM logs")->fetch_assoc()['total'],
    'users' => $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total']
];
header('Content-Type: application/json');
echo json_encode($response);
?>
