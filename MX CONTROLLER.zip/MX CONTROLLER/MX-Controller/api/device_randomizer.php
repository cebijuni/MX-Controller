<?php
require_once '../includes/db.php';

$statuses = ['Online', 'Offline', 'Maintenance'];
$changes = [];

$res = $conn->query("SELECT id, name, status FROM controllers");
while ($row = $res->fetch_assoc()) {
    $newStatus = $statuses[array_rand($statuses)];
    if ($newStatus !== $row['status']) {
        $conn->query("UPDATE controllers SET status='$newStatus' WHERE id={$row['id']}");
        $message = "Device {$row['name']} changed from {$row['status']} to $newStatus";
        $conn->query("INSERT INTO alerts (controller_id, message) VALUES ({$row['id']}, '$message')");
        $changes[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'old_status' => $row['status'],
            'new_status' => $newStatus
        ];
    }
}

echo json_encode(['changes' => $changes]);
