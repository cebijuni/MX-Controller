<?php
require_once '../includes/db.php';

$query = "SELECT status, COUNT(*) as count FROM controllers GROUP BY status";
$result = $conn->query($query);

$data = ['Online' => 0, 'Offline' => 0, 'Maintenance' => 0];
while ($row = $result->fetch_assoc()) {
    $data[$row['status']] = (int)$row['count'];
}

echo json_encode($data);
