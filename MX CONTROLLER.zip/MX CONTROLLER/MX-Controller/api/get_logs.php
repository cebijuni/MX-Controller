<?php
require_once '../includes/db.php';

$data = [];
$result = $conn->query("
    SELECT c.name as controller_name, 
           AVG(l.avg_speed) as avg_speed,
           (SELECT traffic_density FROM logs WHERE controller_id=c.id ORDER BY timestamp DESC LIMIT 1) as traffic_density
    FROM logs l
    JOIN controllers c ON l.controller_id = c.id
    GROUP BY c.id
");

while($row = $result->fetch_assoc()){
    $data[] = $row;
}

header('Content-Type: application/json');
echo json_encode($data);
?>
